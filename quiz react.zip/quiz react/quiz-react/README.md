# Quiz React

```bash
npm install
npm run dev
```
